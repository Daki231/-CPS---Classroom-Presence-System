<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../config/database.php';
require_once '../middleware/auth.php';

$tokenData = validateToken();
$conn = getConnection();

// Total today
$today = date('Y-m-d');
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM attendance WHERE DATE(timestamp) = ?");
$stmt->bind_param("s", $today);
$stmt->execute();
$todayCount = $stmt->get_result()->fetch_assoc()['total'];
$stmt->close();

// Per course
$stmt2 = $conn->prepare("SELECT c.name, COUNT(a.id) as count 
                          FROM attendance a 
                          JOIN courses c ON a.course_id = c.id 
                          GROUP BY c.id, c.name 
                          ORDER BY count DESC");
$stmt2->execute();
$result2 = $stmt2->get_result();
$perCourse = [];
while ($row = $result2->fetch_assoc()) {
    $perCourse[] = $row;
}
$stmt2->close();

// Per day last 7 days
$stmt3 = $conn->prepare("SELECT DATE(timestamp) as day, COUNT(*) as count 
                          FROM attendance 
                          WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                          GROUP BY DATE(timestamp) 
                          ORDER BY day ASC");
$stmt3->execute();
$result3 = $stmt3->get_result();
$perDay = [];
while ($row = $result3->fetch_assoc()) {
    $perDay[] = $row;
}
$stmt3->close();

echo json_encode([
    'today_total' => $todayCount,
    'per_course'  => $perCourse,
    'per_day'     => $perDay
]);

$conn->close();
?>