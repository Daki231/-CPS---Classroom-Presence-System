<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once '../config/database.php';
require_once '../middleware/auth.php';

$tokenData = validateToken();

if ($tokenData['role'] !== 'teacher') {
    http_response_code(403);
    echo json_encode(['error' => 'Only teachers can post attendance']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['records']) || !is_array($data['records'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Records array required']);
    exit;
}

$conn = getConnection();
$inserted = 0;
$skipped = 0;

foreach ($data['records'] as $record) {
    $student_id = intval($record['student_id']);
    $course_id  = intval($record['course_id']);
    $timestamp  = $conn->real_escape_string($record['timestamp']);

    // Check duplicate
    $check = $conn->prepare("SELECT id FROM attendance WHERE student_id = ? AND course_id = ? AND DATE(timestamp) = DATE(?)");
    $check->bind_param("iis", $student_id, $course_id, $timestamp);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $skipped++;
        $check->close();
        continue;
    }
    $check->close();

    $stmt = $conn->prepare("INSERT INTO attendance (student_id, course_id, timestamp) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $student_id, $course_id, $timestamp);
    if ($stmt->execute()) $inserted++;
    $stmt->close();
}

echo json_encode([
    'message'  => 'Sync complete',
    'inserted' => $inserted,
    'skipped'  => $skipped
]);

$conn->close();
?>