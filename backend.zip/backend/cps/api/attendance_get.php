<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../config/database.php';
require_once '../middleware/auth.php';

$tokenData = validateToken();

$conn = getConnection();

$where = [];
$params = [];
$types = "";

if (isset($_GET['date'])) {
    $where[] = "DATE(a.timestamp) = ?";
    $params[] = $_GET['date'];
    $types .= "s";
}
if (isset($_GET['course_id'])) {
    $where[] = "a.course_id = ?";
    $params[] = intval($_GET['course_id']);
    $types .= "i";
}
if (isset($_GET['student_id'])) {
    $where[] = "a.student_id = ?";
    $params[] = intval($_GET['student_id']);
    $types .= "i";
}

// Teachers see only their courses
if ($tokenData['role'] === 'teacher') {
    $where[] = "c.teacher_id = ?";
    $params[] = $tokenData['user_id'];
    $types .= "i";
}

$whereSQL = count($where) > 0 ? "WHERE " . implode(" AND ", $where) : "";

$sql = "SELECT a.id, a.timestamp, u.name AS student_name, u.student_id AS student_code, c.name AS course_name
        FROM attendance a
        JOIN users u ON a.student_id = u.id
        JOIN courses c ON a.course_id = c.id
        $whereSQL
        ORDER BY a.timestamp DESC
        LIMIT 500";

$stmt = $conn->prepare($sql);
if ($types) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$records = [];
while ($row = $result->fetch_assoc()) {
    $records[] = $row;
}

echo json_encode(['records' => $records, 'count' => count($records)]);

$stmt->close();
$conn->close();
?>