const API = 'http://localhost/cps/api';
let token = localStorage.getItem('cps_token');
let userName = localStorage.getItem('cps_user');
let courseChart = null;
let dayChart = null;

// On load
window.onload = () => {
    if (token) {
        showDashboard();
    }
};

// LOGIN
async function login() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const res = await fetch(`${API}/login.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();

        if (data.token) {
            token = data.token;
            userName = data.name;
            localStorage.setItem('cps_token', token);
            localStorage.setItem('cps_user', userName);
            showDashboard();
        } else {
            document.getElementById('loginError').textContent = data.error || 'Login failed';
        }
    } catch (e) {
        document.getElementById('loginError').textContent = 'Cannot connect to server';
    }
}

function logout() {
    localStorage.removeItem('cps_token');
    localStorage.removeItem('cps_user');
    token = null;
    document.getElementById('loginScreen').classList.remove('hidden');
    document.getElementById('dashboardScreen').classList.add('hidden');
}

function showDashboard() {
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('dashboardScreen').classList.remove('hidden');
    document.getElementById('navUser').textContent = `Welcome, ${userName}`;
    loadStats();
    loadAttendance();
}

// STATS + CHARTS
async function loadStats() {
    try {
        const res = await fetch(`${API}/statistics.php`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();

        document.getElementById('statToday').textContent = data.today_total;

        // Course chart
        const courseLabels = data.per_course.map(c => c.name);
        const courseCounts = data.per_course.map(c => c.count);

        if (courseChart) courseChart.destroy();
        courseChart = new Chart(document.getElementById('courseChart'), {
            type: 'bar',
            data: {
                labels: courseLabels,
                datasets: [{
                    label: 'Attendance',
                    data: courseCounts,
                    backgroundColor: '#1a73e8'
                }]
            },
            options: { responsive: true, plugins: { legend: { display: false } } }
        });

        // Day chart
        const dayLabels = data.per_day.map(d => d.day);
        const dayCounts = data.per_day.map(d => d.count);

        if (dayChart) dayChart.destroy();
        dayChart = new Chart(document.getElementById('dayChart'), {
            type: 'line',
            data: {
                labels: dayLabels,
                datasets: [{
                    label: 'Attendance',
                    data: dayCounts,
                    borderColor: '#1a73e8',
                    backgroundColor: 'rgba(26,115,232,0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: { responsive: true, plugins: { legend: { display: false } } }
        });

    } catch (e) {
        console.error('Stats error:', e);
    }
}

// ATTENDANCE TABLE
async function loadAttendance() {
    const date = document.getElementById('filterDate').value;
    let url = `${API}/attendance_get.php`;
    if (date) url += `?date=${date}`;

    try {
        const res = await fetch(url, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();

        document.getElementById('statTotal').textContent = data.count;

        const tbody = document.getElementById('tableBody');
        tbody.innerHTML = '';

        if (data.records.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#888">No records found</td></tr>';
            return;
        }

        data.records.forEach((r, i) => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${i + 1}</td>
                <td>${r.student_name}</td>
                <td>${r.student_code}</td>
                <td>${r.course_name}</td>
                <td>${new Date(r.timestamp).toLocaleString()}</td>
            `;
            tbody.appendChild(tr);
        });

    } catch (e) {
        console.error('Attendance error:', e);
    }
}

function clearFilter() {
    document.getElementById('filterDate').value = '';
    loadAttendance();
}