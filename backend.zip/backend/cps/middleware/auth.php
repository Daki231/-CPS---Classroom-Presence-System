<?php
function generateToken($userId, $role) {
    $header = base64_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $payload = base64_encode(json_encode([
        'user_id' => $userId,
        'role'    => $role,
        'exp'     => time() + 86400
    ]));
    $signature = base64_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    return "$header.$payload.$signature";
}

function validateToken() {
    $headers = getallheaders();
    if (!isset($headers['Authorization'])) {
        http_response_code(401);
        die(json_encode(['error' => 'No token provided']));
    }
    $token = str_replace('Bearer ', '', $headers['Authorization']);
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        http_response_code(401);
        die(json_encode(['error' => 'Invalid token']));
    }
    $signature = base64_encode(hash_hmac('sha256', "$parts[0].$parts[1]", JWT_SECRET, true));
    if ($signature !== $parts[2]) {
        http_response_code(401);
        die(json_encode(['error' => 'Invalid token signature']));
    }
    return json_decode(base64_decode($parts[1]), true);
}
?>